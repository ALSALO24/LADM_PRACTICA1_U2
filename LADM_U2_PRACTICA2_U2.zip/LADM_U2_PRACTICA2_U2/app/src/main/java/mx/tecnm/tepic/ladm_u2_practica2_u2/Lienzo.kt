package mx.tecnm.tepic.ladm_u2_practica2_u2

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.CountDownTimer
import android.view.View

class Lienzo(act:MainActivity): View(act) {

    val principal = act
    val calaca1 = BitmapFactory.decodeResource(principal.resources, R.drawable.calaca1)
    val calaca2 = BitmapFactory.decodeResource(principal.resources, R.drawable.calaca2)
    val tumba = BitmapFactory.decodeResource(principal.resources, R.drawable.tumba_opt)
    val calav = BitmapFactory.decodeResource(principal.resources, R.drawable.calavera_preview_rev_1_opt)
    val deco = BitmapFactory.decodeResource(principal.resources, R.drawable.decoracion_opt)
    var posX = 2200f
    var posX2 = -200f

    val movimientoCalabera = object: CountDownTimer(2000,80){
        override fun onTick(p0: Long){
            posX-=5
            posX2+=5
            if(posX <-500) {posX = 2200f
                posX2 = -200f}
            invalidate()//forza a onDraw a volverse a llamar, para repintar el trineo en nueva posicion
        }
        override fun onFinish(){
            start()
        }
    }

    init{
        movimientoCalabera.start()
    }


    override fun onDraw(c: Canvas){

        super.onDraw(c)
        c.drawColor(Color.BLACK)

        //LUNA
        val p = Paint()
        p.color = Color.WHITE
        c.drawCircle(200f,100f,80f,p)
        p.color = Color.BLACK
        c.drawCircle(240f,80f,60f,p)

        //NUBES
        p.color = Color.rgb(231,235,218)
        c.drawOval(400f,200f,800f,80f,p)
        c.drawOval(600f,200f,1000f,80f,p)

        c.drawOval(700f,150f,1100f,80f,p)
        c.drawOval(900f,150f,1300f,80f,p)

        c.drawOval(1500f,170f,1800f,100f,p)
        c.drawOval(1650f,170f,1950f,100f,p)

        //montana izquierda 1
        p.color = Color.rgb(0,143,57)
        c.drawOval(-500f,600f,700f,1300f,p);
        p.style = Paint.Style.STROKE
        p.strokeWidth = 4.0f
        p.color = Color.rgb(78,59,49);
        c.drawOval(-500f,600f,700f,1300f,p);

        //montana izquierda 2
        p.color = Color.rgb(0,143,57)
        p.style = Paint.Style.FILL
        c.drawOval(-100f,600f,1600f,1300f,p);
        p.style = Paint.Style.STROKE
        p.strokeWidth = 4.0f
        p.color = Color.rgb(78,59,49);
        c.drawOval(-100f,600f,1600f,1300f,p);

        //montana derecha
        p.color = Color.rgb(0,143,57)
        p.style = Paint.Style.FILL
        c.drawOval(900f,500f,2500f,1300f,p);
        p.style = Paint.Style.STROKE
        p.strokeWidth = 4.0f
        p.color = Color.rgb(78,59,49);
        c.drawOval(900f,500f,2500f,1300f,p);

        //arbol
        p.color = Color.rgb(180,114,20);
        p.style = Paint.Style.FILL
        c.drawRect(500f,700f,550f,800f,p);
        p.color = Color.rgb(45,87,44);
        c.drawOval(450f,630f,600f,720f,p)
        c.drawOval(450f,560f,600f,650f,p)

        //arbol2
        p.color = Color.rgb(180,114,20);
        c.drawRect(1300f,600f,1400f,750f,p);
        p.color = Color.rgb(45,87,44);
        c.drawOval(1200f,480f,1500f,650f,p)
        c.drawOval(1200f,380f,1500f,570f,p)

        //arbol3
        p.color = Color.rgb(180,114,20);
        c.drawRect(1600f,400f,1700f,550f,p);
        p.color = Color.rgb(45,87,44);
        c.drawOval(1500f,280f,1800f,450f,p)
        c.drawOval(1500f,180f,1800f,370f,p)

        //arbol4
        p.color = Color.rgb(180,114,20);
        p.style = Paint.Style.FILL
        c.drawRect(800f,700f,850f,500f,p);
        p.color = Color.rgb(45,87,44);
        c.drawOval(750f,630f,900f,520f,p)
        c.drawOval(750f,560f,900f,450f,p)

        //arbol5
        p.color = Color.rgb(180,114,20);
        p.style = Paint.Style.FILL
        c.drawRect(100f,670f,150f,500f,p);
        p.color = Color.rgb(45,87,44);
        c.drawOval(50f,580f,200f,520f,p)
        c.drawOval(50f,530f,200f,470f,p)

        //TUMBAS
        c.drawBitmap(tumba, 250f,550f,p)
        c.drawBitmap(tumba, 570f,600f,p)
        c.drawBitmap(tumba, 1050f,650f,p)
        c.drawBitmap(tumba, 1470f,470f,p)
        c.drawBitmap(tumba, 1760f,500f,p)

        c.drawBitmap(calaca1, posX,500f,p)
        c.drawBitmap(calaca2, posX2,570f,p)

        c.drawBitmap(calav, 1600f,0f,p)
        c.drawBitmap(deco, 0f,250f,p)
        c.drawBitmap(deco, 600f,260f,p)
        c.drawBitmap(deco, 1200f,250f,p)
        c.drawBitmap(deco, 1800f,260f,p)




    }
}